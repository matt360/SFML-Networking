#pragma once

//enum direction : char { left = 'l', right = 'r' };



